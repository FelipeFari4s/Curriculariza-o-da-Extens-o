============================================================
                  INVENTORY TELEGRAM BOT
============================================================

Description:
-------------
This is a Telegram inventory management bot written in Rust,
using the "frankenstein" library to interact with the Telegram API.

Each chat manages its own inventory using commands like:
  /add, /sub, /set, /remove, and /list.

All inventories are saved automatically to a file named:
  inventories.json


============================================================
                   SETUP INSTRUCTIONS
============================================================

1. Install Rust
---------------
If you don’t have Rust installed yet, download it from:
https://www.rust-lang.org/tools/install

After installation, verify with:
  rustc --version
  cargo --version


2. Clone or Copy the Project
----------------------------
Use Git to clone the repository, or copy the code files manually.

Example:
  git clone https://github.com/murilo-ferrari/Telegram-Storage-Bot.git
  cd inventory-telegram-bot


3. Create a .env File
---------------------
This project uses dotenv to read your Telegram bot token.

In the same folder as your Cargo.toml, create a file named:
  .env

Add this line inside it:
  TELEGRAM_BOT_TOKEN=your_bot_token_here

Replace "your_bot_token_here" with your actual Telegram bot token,
which you can get from @BotFather on Telegram.


4. Change the Bot Name (IMPORTANT)
----------------------------------
Your bot is currently configured with the name:
  @SocorroDuds_bot

If someone else wants to use this bot, they must change it to
their own bot’s username (including the @ symbol).

To do this:
  - Open the main.rs file.
  - Find the line:
      let bot_name = "@SocorroDuds_bot";
  - Replace it with your own bot’s name. For example:
      let bot_name = "@LucasInventoryBot";

You also need to update the bot name inside the "handle_command"
function, where commands like /add@SocorroDuds_bot appear.

You can use your editor’s “Find and Replace” feature to replace
all instances of "@SocorroDuds_bot" with your bot’s handle.


5. Run the Bot
--------------
Use Cargo to build and start the bot:

  cargo run

If everything is correct, you should see:
  Inventory bot is running…

Now open Telegram, find your bot, and send a command like:
  /add@SocorroDuds_bot Banana 10


============================================================
                     BOT COMMANDS
============================================================

  /add@BotName <item> <amount>
      Adds a new item or increases its quantity.
      Example: /add@SocorroDuds_bot Banana 10

  /sub@BotName <item> <amount>
      Subtracts a quantity from an item.
      Example: /sub@SocorroDuds_bot Banana 3

  /set@BotName <item> <amount>
      Sets an item’s amount directly.
      Example: /set@SocorroDuds_bot Banana 20

  /remove@BotName <item>
      Deletes an item from the inventory.
      Example: /remove@SocorroDuds_bot Banana

  /list@BotName
      Displays all items and their quantities.
      Example: /list@SocorroDuds_bot


============================================================
                      DATA STORAGE
============================================================

All inventories are stored in a local file named:
  inventories.json

Each Telegram chat has its own separate inventory, saved using
its chat ID as the key.

The bot automatically creates and updates this file whenever
you modify your inventory.


============================================================
               RUNNING IN THE BACKGROUND
============================================================

If you want your bot to keep running even after you close the
terminal, you can use one of these commands:

  nohup cargo run &

Or run it in a terminal session manager like:
  tmux
  screen
  systemd (for servers)


============================================================
                        AUTHOR
============================================================

Created by: Murilo Ferrari
Built with: Rust + Frankenstein Library
Purpose: Simple Telegram inventory tracker bot

