use std::{env, fs, thread, time::Duration};
use std::collections::HashMap;
use std::fs::File;
use std::io::Write;

use frankenstein::{client_ureq::Bot, TelegramApi};
use frankenstein::methods::{GetUpdatesParams, SendMessageParams};
use frankenstein::updates::UpdateContent;

use serde_json;

fn main() {
    dotenv::dotenv().ok();

    let token = env::var("TELEGRAM_BOT_TOKEN")
        .expect("TELEGRAM_BOT_TOKEN is not set");

    let bot = Bot::new(&token);


    let mut inventories: HashMap<i64, HashMap<String, i32>> = load_inventories("inventories.json");
    let mut offset: i64 = 0;

    println!("Inventory bot is running…");

    loop {
        //ask telegram for updates
        let updates = bot
            .get_updates(&GetUpdatesParams::builder()
                .offset(offset)
                .timeout(10)
                .build())
            .expect("failed do get updates");

        for update in updates.result {

            println!("{:#?}", update);
            let msg = match update.content{
                UpdateContent::Message(msg) => {msg}
                x => {
                    println!("{:?}", x);
                    continue;
                }
            };
            let chat_id = msg.chat.id;
            let text = msg.text.unwrap_or_default();

            let bot_name = "@SocorroDuds_bot";

            if !text.contains(bot_name) {
                continue; // skip messages that don't mention the bot
            }

            let reply_text = handle_command(&mut inventories, chat_id, &text);

            let reply = SendMessageParams::builder()
                .chat_id(chat_id)
                .text(reply_text)
                .build();

            bot.send_message(&reply).expect("Failed to send message");

            offset = update.update_id as i64 + 1;
        }
        thread::sleep(Duration::from_millis(100));
    }
}

fn handle_command(
    inventories: &mut HashMap<i64, HashMap<String, i32>>,
    chat_id: i64,
    text: &str
) -> String {

    let parts: Vec<&str> = text.trim().split_whitespace().collect();

    if parts.is_empty() {
        return "Please input a valid command.".into();
    }

    match parts[0] {
        "/add@SocorroDuds_bot" if parts.len() >= 3 => {
            let value = parts[parts.len() - 1];
            let value: i32 = match value.parse() {
                Ok(v) => v,
                Err(_) => return "Invalid number. Usage: /add <item> <integer>".into(),
            };

            let item = parts[1..parts.len() - 1].join(" ");

            let item = set_key(&item);

            /*
            let mut item_chars: Vec<char> = Vec::new();
            for c in item.chars() {
                if c.is_alphanumeric() {
                    item_chars.push(c);
                }
            }
            let item: String = item_chars.into_iter().collect();
            let item: String = item.to_lowercase();
            */

            let inv = inventories.entry(chat_id).or_default();
            *inv.entry(item.clone()).or_insert(0) += value;

            save_inventories(inventories, "inventories.json")
                .expect("Failed to save inventories");

            format!("Added {} units of {}", value, item)
        }

        "/sub@SocorroDuds_bot" if parts.len() >= 3 => {
            let value = parts[parts.len() - 1];
            let value: i32 = match value.parse() {
                Ok(v) => v,
                Err(_) => return "Invalid number. Usage: /add <item> <integer>".into(),
            };

            let item = parts[1..parts.len() - 1].join(" ");

            let item = set_key(&item);

            /*
            let mut item_chars: Vec<char> = Vec::new();
            for c in item.chars() {
                if c.is_alphanumeric() {
                    item_chars.push(c);
                }
            }
            let item: String = item_chars.into_iter().collect();
            let item: String = item.to_lowercase();
            */

            let inv = inventories.entry(chat_id).or_default();
            let entry = inv.entry(item.clone()).or_insert(0);
            if *entry - value < 0 {
                "Cant have negative values!".to_string()
            }else {
                *entry -= value;

                save_inventories(inventories, "inventories.json")
                    .expect("Failed to save inventories");

                format!("Removed {} units from {}", value, item)
            }
        }

        "/set@SocorroDuds_bot" if parts.len() >= 3 => {
            let value = parts[parts.len() - 1];
            let value: i32 = match value.parse() {
                Ok(v) => v,
                Err(_) => return "Invalid number. Usage: /add <item> <integer>".into(),
            };

            let item = parts[1..parts.len() - 1].join(" ");

            let item = set_key(&item);

            /*
            let mut item_chars: Vec<char> = Vec::new();
            for c in item.chars() {
                if c.is_alphanumeric() {
                    item_chars.push(c);
                }
            }
            let item: String = item_chars.into_iter().collect();
            let item: String = item.to_lowercase();
            */

            let inv = inventories.entry(chat_id).or_default();

            match inv.get(&item) {
                Some(_) => {
                    inv.insert(item.clone(), value);

                    save_inventories(inventories, "inventories.json")
                        .expect("Failed to save inventories");

                    format!("{} is set to {} units", item, value)
                }
                None => {
                    format!("Couldn't find {} in the list", item)
                }
            }
        }

        "/remove@SocorroDuds_bot" if parts.len() >= 2 => {
            let item = parts[1..parts.len()].join(" ");

            let item = set_key(&item);

            let inv = inventories.entry(chat_id).or_default();

            if inv.remove(&item).is_some() {

                save_inventories(inventories, "inventories.json")
                    .expect("Failed to save inventories");

                format!("Removed '{}' from the list inventory.", item)
            } else {
                format!("Item '{}' does not exist in the inventory.", item)
            }
        }

        "/list@SocorroDuds_bot" => {
            if let Some(inv) = inventories.get(&chat_id) {
                if inv.is_empty() {
                    "Inventory is empty.".into()
                } else {
                    let output = {
                        format!(
                            "The current storage is:\n{}",
                            inv.iter()
                                .map(|(k, v)| format!("{}: {}", k, v))
                                .collect::<Vec<_>>()
                                .join("\n")
                        )
                    };
                    output
                }
            } else {
                "Inventory is empty.".into()
            }
        }

        _ => "Unknown command. Use /add, /sub, /set, /list".into()
    }
}

fn set_key(s: &str) -> String {
    s.split_whitespace() // splits by any whitespace and ignores empty segments
        .map(|word| {
            let mut chars = word.chars();
            match chars.next() {
                Some(first) => first.to_uppercase().collect::<String>() + &chars.as_str().to_lowercase(),
                None => String::new(),
            }
        })
        .collect::<Vec<_>>()      // collect each processed word
        .join(" ")                // join with a single space
}

fn save_inventories(
    inventories: &HashMap<i64, HashMap<String, i32>>,
    path: &str
) -> std::io::Result<()> {
    let json = serde_json::to_string_pretty(inventories)
        .expect("Failed to serialize inventories.");

    let mut file = File::create(path)?;
    file.write_all(json.as_bytes())?;

    Ok(())
}

fn load_inventories(
    path: &str
) -> HashMap<i64, HashMap<String, i32>> {
    match fs::read_to_string(path) {
        Ok(data) => serde_json::from_str(&data).unwrap_or_default(),
        Err(_) => HashMap::new(),
    }
}